Dough
Pizza Sauce
Cheese
pepper & salt
mushrooms
tomatoes
onions
yeast and finally oil